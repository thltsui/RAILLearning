# What is Pidgin?
Pidgin is African's English. It is also referred as "Broken Language". 
### Fun facts: There are slight variation in the speaking in West-African conutries but it still well understood amongst the citizens.  
### It is mostly used to communicate among the Youth and Elderly.
