from phe import paillier
from phe.paillier import generate_paillier_keypair

keygen = generate_paillier_keypair
